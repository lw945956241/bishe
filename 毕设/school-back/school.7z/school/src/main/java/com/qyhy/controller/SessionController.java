package com.qyhy.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author qyhy
 * @since 2021-03-23
 */
@RestController
@RequestMapping("/session")
public class SessionController {

}

