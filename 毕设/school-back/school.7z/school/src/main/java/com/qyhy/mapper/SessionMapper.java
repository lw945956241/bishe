package com.qyhy.mapper;

import com.qyhy.entity.Session;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author qyhy
 * @since 2021-03-23
 */
public interface SessionMapper extends BaseMapper<Session> {

}
